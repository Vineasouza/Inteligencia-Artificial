--Integrantes--- 
Lucas de Almeida, RA: 1996762
Vinícius Augusto de Souza, RA: 1997530

--Parte 1--: 
Database -> Iris - https://archive.ics.uci.edu/ml/datasets/Iris
Modelo ML -> Decision Tree - https://scikit-learn.org/stable/modules/tree.html

--Parte 2--:
Database -> Shapes - https://www.kaggle.com/cactus3/basicshapes
Arquiteturas: 	- Xception - https://keras.io/api/applications/xception/
		- InceptionResNetV2 - https://keras.io/api/applications/inceptionresnetv2/
